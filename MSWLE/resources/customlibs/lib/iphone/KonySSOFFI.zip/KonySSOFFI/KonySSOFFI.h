//
//  KonySSOFFI.h
//  KonySSOFFI
//
//  Created by Rama Guduri on 12/5/17.
//  Copyright © 2017 Chevron. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CallBack.h"
#import <ADAL/ADAL.h>
#import <ADAL/ADAuthenticationContext.h>

@interface KonySSOFFI : NSObject

// AuthenticationContext methods
+ (void)acquireTokenAsync:(NSDictionary *)params
          successCallback:(CallBack *)successCallback
            errorCallback:(CallBack *)errorCallback;

+ (void)acquireTokenSilentAsync:(NSDictionary *)params
                successCallback:(CallBack *)successCallback
                  errorCallback:(CallBack *)errorCallback;

// TokenCache methods
+ (void)tokenCacheClear:(CallBack *)successCallback
          errorCallback:(CallBack *)errorCallback;

+ (void)tokenCacheReadItems:(CallBack *)successCallback
              errorCallback:(CallBack *)errorCallback;


//- (void)tokenCacheDeleteItem:(CDVInvokedUrlCommand *)command;

+ (ADAuthenticationContext *)getOrCreateAuthContext:(NSString *)authority
                                  validateAuthority:(BOOL)validate;

+ (NSArray *) getArrayJSONFromDictionary:(NSDictionary *)dict;

+ (BOOL)schemeAvailable:(NSString *)scheme;

@end

