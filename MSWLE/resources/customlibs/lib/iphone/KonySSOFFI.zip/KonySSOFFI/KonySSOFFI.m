//
//  KonySSOFFI.m
//  KonySSOFFI
//
//  Created by Rama Guduri on 12/5/17.
//  Copyright © 2017 Chevron. All rights reserved.
//

#import "KonySSOFFI.h"
#import "CordovaAdalUtils.h"
#import <ADAL/ADAL.h>
#import <ADAL/ADAuthenticationContext.h>

@implementation KonySSOFFI

+ (void)acquireTokenAsync:(NSDictionary*)params
          successCallback:(CallBack *)successCallback
            errorCallback:(CallBack *)errorCallback;
{
    dispatch_async(dispatch_get_main_queue(), ^{
        @try
        {
            NSString *authority = ObjectOrNil(params[@"authority"]);
            BOOL validateAuthority = [params[@"validateAuthority"] boolValue];
            NSString *resourceId = ObjectOrNil(params[@"resourceId"]);
            NSString *clientId = ObjectOrNil(params[@"clientId"]);
            NSURL *redirectUri = [NSURL URLWithString:params[@"redirectUri"]];
            NSString *userId = ObjectOrNil(params[@"userId"]);
            NSString *extraQueryParameters = ObjectOrNil(params[@"extraQueryParameters"]);
            
            ADAuthenticationError *error = nil;
            ADAuthenticationContext *authContext = [[ADAuthenticationContext alloc] initWithAuthority:authority
                                                                                    validateAuthority:validateAuthority
                                                                                                error:&error];
            
            if (error != nil)
            {
                NSMutableDictionary * result = [CordovaAdalUtils ADAuthenticationErrorToDictionary:error];
                [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:result]];
            }
            // `x-msauth-` redirect url prefix means we should use brokered authentication
            // https://github.com/AzureAD/azure-activedirectory-library-for-objc#brokered-authentication
            authContext.credentialsType = (redirectUri.scheme && [redirectUri.scheme hasPrefix: @"x-msauth-"]) ?
            AD_CREDENTIALS_AUTO : AD_CREDENTIALS_EMBEDDED;
            
            // TODO iOS sdk requires user name instead of guid so we should map provided id to a known user name
            userId = [CordovaAdalUtils mapUserIdToUserName:authContext
                                                    userId:userId];
            dispatch_async(dispatch_get_main_queue(), ^{
                [authContext
                 acquireTokenWithResource:resourceId
                 clientId:clientId
                 redirectUri:redirectUri
                 promptBehavior:AD_PROMPT_ALWAYS
                 userId:userId
                 extraQueryParameters:extraQueryParameters
                 completionBlock:^(ADAuthenticationResult *result) {
                     
                     NSMutableDictionary *msg = [CordovaAdalUtils ADAuthenticationResultToDictionary: result];
                     if(AD_SUCCEEDED == result.status){
                         [successCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:msg]];
                     }else{
                         [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:msg]];
                     }
                 }];
            });
        }
        @catch (ADAuthenticationError *error)
        {
            NSMutableDictionary * result = [CordovaAdalUtils ADAuthenticationErrorToDictionary:error];
            [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:result]];
        }
    });
}

+ (void)acquireTokenSilentAsync:(NSDictionary*)params
                successCallback:(CallBack *)successCallback
                  errorCallback:(CallBack *)errorCallback
{
    @try
    {
        NSString *authority = ObjectOrNil(params[@"authority"]);
        BOOL validateAuthority = [params[@"validateAuthority"] boolValue];
        NSString *resourceId = ObjectOrNil(params[@"resourceId"]);
        NSString *clientId = ObjectOrNil(params[@"clientId"]);
        NSString *userId = ObjectOrNil(params[@"userId"]);
        
        ADAuthenticationContext *authContext = [KonySSOFFI getOrCreateAuthContext:authority
                                                                validateAuthority:validateAuthority];
        
        // TODO iOS sdk requires user name instead of guid so we should map provided id to a known user name
        userId = [CordovaAdalUtils mapUserIdToUserName:authContext
                                                userId:userId];
        
        [authContext acquireTokenSilentWithResource:resourceId
                                           clientId:clientId
                                        redirectUri:nil
                                             userId:userId
                                    completionBlock:^(ADAuthenticationResult *result) {
                                        NSMutableDictionary *msg = [CordovaAdalUtils ADAuthenticationResultToDictionary: result];
                                        if(AD_SUCCEEDED != result.status){
                                            [successCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:msg]];
                                        }else{
                                            [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:msg]];
                                        }
                                    }];
    }
    @catch (ADAuthenticationError *error)
    {
        NSMutableDictionary * result = [CordovaAdalUtils ADAuthenticationErrorToDictionary:error];
        [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:result]];
    }
}

+ (void)tokenCacheClear:(CallBack *)successCallback
          errorCallback:(CallBack *)errorCallback
{
    @try
    {
        ADAuthenticationError *error;
        
        ADKeychainTokenCache* cacheStore = [ADKeychainTokenCache new];
        
        NSArray *cacheItems = [cacheStore allItems:&error];
        
        for (int i = 0; i < cacheItems.count; i++)
        {
            [cacheStore removeItem: cacheItems[i] error: &error];
        }
        
        if (error != nil)
        {
            [errorCallback executeWithArguments:nil];
        }
        
        [successCallback executeWithArguments:nil];
    }
    @catch (ADAuthenticationError *error)
    {
        NSMutableDictionary * result = [CordovaAdalUtils ADAuthenticationErrorToDictionary:error];
        [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:result]];
    }
}

+ (void)tokenCacheReadItems:(CallBack *)successCallback
              errorCallback:(CallBack *)errorCallback
{
    @try
    {
        ADAuthenticationError *error;
        
        ADKeychainTokenCache* cacheStore = [ADKeychainTokenCache new];
        
        //get all items from cache
        NSArray *cacheItems = [cacheStore allItems:&error];
        
        NSMutableArray *items = [NSMutableArray arrayWithCapacity:cacheItems.count];
        
        if (error != nil)
        {
            @throw(error);
        }
        
        for (id obj in cacheItems)
        {
            [items addObject:[CordovaAdalUtils ADTokenCacheStoreItemToDictionary:obj]];
        }
        
        [errorCallback executeWithArguments:items];
    }
    @catch (ADAuthenticationError *error)
    {
        NSMutableDictionary * result = [CordovaAdalUtils ADAuthenticationErrorToDictionary:error];
        [errorCallback executeWithArguments:[KonySSOFFI getArrayJSONFromDictionary:result]];
    }
}


+ (ADAuthenticationContext *)getOrCreateAuthContext:(NSString *)authority
                                  validateAuthority:(BOOL)validate
{
    
    ADAuthenticationContext *authContext = nil;
    
    if (!authContext)
    {
        ADAuthenticationError *error = nil;
        
        authContext = [ADAuthenticationContext authenticationContextWithAuthority:authority
                                                                validateAuthority:validate
                                                                            error:&error];
        if (error != nil)
        {
            @throw(error);
        }
        
    }
    
    return authContext;
}

+ (NSArray *)getArrayJSONFromDictionary:(NSDictionary *)dict
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
        return nil;
    } else {
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSArray *arr = [NSArray arrayWithObjects:@[jsonString], nil];
        return arr;
    }
}

+ (BOOL)schemeAvailable:(NSString *)scheme {
    UIApplication *application = [UIApplication sharedApplication];
    NSURL *URL = [NSURL URLWithString:scheme];
    return [application canOpenURL:URL];
}

static id ObjectOrNil(id object)
{
    return [object isKindOfClass:[NSNull class]] ? nil : object;
}

@end

